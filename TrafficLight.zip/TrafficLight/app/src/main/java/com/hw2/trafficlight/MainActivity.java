package com.hw2.trafficlight;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    private ImageView ivLight;
    private Button btnChange;
    private int currentLight = 1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initialize();
        registerChangeListener();
    }

    private void initialize() {
        ivLight = findViewById(R.id.iv_light_color);
        btnChange = findViewById(R.id.btn_change);
    }

    private void registerChangeListener() {
        btnChange.setOnClickListener(changeListener);
    }


    //set listener,use currentLight to change color
    private View.OnClickListener changeListener = new View.OnClickListener() {
        public void onClick(View v) {
            if(v.getId() == R.id.btn_change){
                if(currentLight == 1){
                    ivLight.setImageResource(R.drawable.ic_green_light);
                    btnChange.setText(getResources().getText(R.string.go));
                    btnChange.setBackgroundColor(getResources().getColor(R.color.green));
                    currentLight = 2;
                }else if(currentLight == 2){
                    ivLight.setImageResource(R.drawable.ic_yellow_light);
                    btnChange.setText(getResources().getText(R.string.wait));
                    btnChange.setBackgroundColor(getResources().getColor(R.color.yellow));
                    currentLight = 3;
                }else{
                    ivLight.setImageResource(R.drawable.ic_red_light);
                    btnChange.setText(getResources().getText(R.string.stop));
                    btnChange.setBackgroundColor(getResources().getColor(R.color.red));
                    currentLight = 1;
                }
            }
        }
    };
}